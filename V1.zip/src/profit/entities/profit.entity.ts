export class Profit {}
