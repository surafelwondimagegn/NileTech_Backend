export class CreateProfitDto {}
