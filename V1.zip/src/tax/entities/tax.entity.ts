export class Tax {}
