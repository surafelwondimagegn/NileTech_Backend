export class Budget {}
