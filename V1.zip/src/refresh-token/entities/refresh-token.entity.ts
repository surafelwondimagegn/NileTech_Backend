export class RefreshToken {}
