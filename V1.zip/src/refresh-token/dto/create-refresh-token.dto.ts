export class CreateRefreshTokenDto {}
