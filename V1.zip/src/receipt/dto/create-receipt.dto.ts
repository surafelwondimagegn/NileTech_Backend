export class CreateReceiptDto {}
