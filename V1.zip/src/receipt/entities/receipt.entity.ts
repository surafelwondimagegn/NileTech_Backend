export class Receipt {}
