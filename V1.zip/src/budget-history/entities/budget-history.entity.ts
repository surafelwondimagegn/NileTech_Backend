export class BudgetHistory {}
